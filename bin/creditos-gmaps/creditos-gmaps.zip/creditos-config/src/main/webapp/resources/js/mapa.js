$(document).ready(function(){
  map = new GMaps({
    div: '#map',
    lat: latitud,
    lng: longitud
  });
  
  map.addMarker({
            lat: map.getCenter().lat(),
            lng: map.getCenter().lng(),
            draggable: true,
            dragend: function (e, d) {
				$('#lat').val(e.latLng.lat());
				$('#lng').val(e.latLng.lng());
            }
        });
});
