$(document).ready(function() {
	 $('#btnRight').click(function(e) {
	        var selectedOpts = $('#lstBox1 option:selected');
	        if (selectedOpts.length == 0) {
	            alert("Nothing to move.");
	            e.preventDefault();
	        }

	        $('#lstBox2').append($(selectedOpts).clone());
	        $('#lstBox2').find("option").attr('selected', 'selected'); 
	        $(selectedOpts).remove();
	        e.preventDefault();
	    });

	    $('#btnLeft').click(function(e) {
	        var selectedOpts = $('#lstBox2 option:selected');
	        if (selectedOpts.length == 0) {
	            alert("Nothing to move.");
	            e.preventDefault();
	        }

	        $('#lstBox1').append($(selectedOpts).clone());
	        $(selectedOpts).remove();
	        e.preventDefault();
	    });
});
