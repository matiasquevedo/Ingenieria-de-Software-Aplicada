 $(document).ready(function() {
            $('#dataTables').DataTable({
                responsive: true
            });
        });
