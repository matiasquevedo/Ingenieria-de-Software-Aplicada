    var map;

    function loadResults (data) {
      var items, markers_data = [];
      
        items = data;

        for (var i = 0; i < items.length; i++) {
          var item = items[i];

          if (item.lat != undefined && item.lng != undefined) {
            var icon = 'https://ss3.4sqi.net/img/categories/education/default.png';

            markers_data.push({
              lat : item.lat,
              lng : item.lng,
              title : item.nombre,
              icon : {
                size : new google.maps.Size(32, 32),
                url : icon
              }
            });
          }
        }
      

      map.addMarkers(markers_data);
    }

  
    $(document).ready(function(){
      
      map = new GMaps({
        div: '#map',
        lat: -34.616292,
        lng: -68.32994
      });

      map.on('marker_added', function (marker) {
        var index = map.markers.indexOf(marker);

        if (index == map.markers.length - 1) {
          map.fitZoom();
        }
      });

      var xhr = $.getJSON('http://localhost:8181/um/gmaps/jsonAll');

      xhr.done(loadResults);
    });
