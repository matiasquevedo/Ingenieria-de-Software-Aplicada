package ar.edu.um.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.um.domain.Anio;
import ar.edu.um.repository.AlumnoRepository;
import ar.edu.um.repository.AnioRepository;
import ar.edu.um.services.AlumnoService;
import ar.edu.um.services.AnioService;
@Service
@Transactional
public class AnioServiceImpl implements AnioService {
	private static final int PAGE_SIZE = 50;
	@Autowired
	private AnioRepository dao;
	@Override
	public void create(Anio entity) {
		dao.save(entity);

	}

	@Override
	public void remove(Anio entity) {
		dao.delete(entity);

	}

	@Override
	public void update(Anio entity) {
		dao.save(entity);
		dao.flush();
	}

	@Override
	public Anio findById(Integer id) {
		return dao.findOne(id);
	}

	@Override
	public List<Anio> findAll() {
		return dao.findAll();
	}

}
