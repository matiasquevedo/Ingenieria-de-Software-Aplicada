package ar.edu.um.form;

import java.beans.PropertyEditorSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import ar.edu.um.domain.Anio;
import ar.edu.um.services.AnioService;

public class AnioEditor extends PropertyEditorSupport {

	@Autowired
	private AnioService anioService;
	private static final Logger logger = LoggerFactory.getLogger(AnioEditor.class);

	public AnioEditor(AnioService anioService) {
		this.anioService = anioService;
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		Anio anio = anioService.findById(Integer.parseInt(text));
		setValue(anio);
	}

}
