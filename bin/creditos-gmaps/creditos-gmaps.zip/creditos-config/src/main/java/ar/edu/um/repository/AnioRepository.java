package ar.edu.um.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.um.domain.Anio;

public interface AnioRepository extends JpaRepository<Anio, Integer> {

}
