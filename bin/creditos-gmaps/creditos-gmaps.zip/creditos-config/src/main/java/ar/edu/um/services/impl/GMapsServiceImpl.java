package ar.edu.um.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.um.domain.GMaps;
import ar.edu.um.repository.GMapsRepository;
import ar.edu.um.services.GMapsService;

@Service
@Transactional
public class GMapsServiceImpl implements GMapsService {

	@Autowired
	private GMapsRepository dao;

	@Override
	public void create(GMaps entity) {
		dao.save(entity);

	}

	@Override
	public void remove(GMaps entity) {
		dao.delete(entity);

	}

	@Override
	public void update(GMaps entity) {
		dao.save(entity);
		dao.flush();
	}

	@Override
	public GMaps findById(Integer id) {
		return dao.findOne(id);
	}

	@Override
	public List<GMaps> findAll() {
		return dao.findAll();
	}

}
