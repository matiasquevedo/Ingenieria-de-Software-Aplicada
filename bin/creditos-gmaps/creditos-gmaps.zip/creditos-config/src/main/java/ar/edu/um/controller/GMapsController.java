package ar.edu.um.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ar.edu.um.domain.GMaps;
import ar.edu.um.services.GMapsService;

@Controller
@RequestMapping("/gmaps")
public class GMapsController {
	
	@Autowired
	private GMapsService gmapsService;
	
	private static final Logger logger = LoggerFactory
			.getLogger(GMapsController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Model model) {
		model.addAttribute("gmaps", gmapsService.findAll());
		return "gmaps/tabla";
	}
	
	@RequestMapping(value = "/jsonAll", method = RequestMethod.GET)
	public @ResponseBody List<GMaps> jsonAll(Model model) {
		return gmapsService.findAll();
	}
	
	@RequestMapping(value = "/nuevo", method = RequestMethod.GET)
	public String nuevo(Model model){
		model.addAttribute("gmaps", new GMaps());
		return "gmaps/nuevo";
	}
	
	@RequestMapping(value="/nuevo", method= RequestMethod.POST)
	public String form(@Valid GMaps gmaps, BindingResult result,
			Model model, final RedirectAttributes redirectAttributes){
		if (!result.hasErrors()) {
			gmapsService.create(gmaps);
			redirectAttributes.addFlashAttribute("message", "GMaps Agregado.");
			redirectAttributes.addFlashAttribute("cssmessage", "alert-success");
			return "redirect:/gmaps/";
		} else {
			for (ObjectError error : result.getAllErrors()) {
				logger.info("Validation error: " + error.getDefaultMessage());
			}
		}
		return "gmaps/nuevo";
	}
	
	@RequestMapping(value = "/{id}/editar", method = RequestMethod.GET)
	public String editar(@PathVariable("id") Integer id, Model model) {
		GMaps gmaps = gmapsService.findById(id);
		model.addAttribute("gmaps", gmaps);
		return "gmaps/editar";
	}
	
	@RequestMapping(value="/{id}/editar", method= RequestMethod.POST)
	public String formEditar(@Valid GMaps gmaps, BindingResult result,
			Model model, final RedirectAttributes redirectAttributes){
		if (!result.hasErrors()) {
			gmapsService.update(gmaps);
			redirectAttributes.addFlashAttribute("message", "GMaps actualizado.");
			redirectAttributes.addFlashAttribute("cssmessage", "alert-success");
			return "redirect:/gmaps/";
		} else {
			for (ObjectError error : result.getAllErrors()) {
				logger.info("Validation error: " + error.getDefaultMessage());
			}
		}
		return "gmaps/editar";
	}
	
	@RequestMapping(value = "/{id}/borrar", method = RequestMethod.GET)
	public String borrar(@PathVariable("id") Integer id, Model model, final RedirectAttributes redirectAttributes) {
		GMaps gmaps = gmapsService.findById(id);
		if(gmaps != null){
			gmapsService.remove(gmaps);
			redirectAttributes.addFlashAttribute("message", "GMaps Borrado.");
			redirectAttributes.addFlashAttribute("cssmessage", "alert-warning");
		}
		
		return "redirect:/gmaps/";
	}
	
}
