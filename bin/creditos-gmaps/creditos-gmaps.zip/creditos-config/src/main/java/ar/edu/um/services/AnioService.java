package ar.edu.um.services;

import java.util.List;

import ar.edu.um.domain.Anio;

public interface AnioService {
	void create(final Anio entity);
	void remove(final Anio entity);
	void update(final Anio entity);
	Anio findById(final Integer id);

	List<Anio> findAll();
}
