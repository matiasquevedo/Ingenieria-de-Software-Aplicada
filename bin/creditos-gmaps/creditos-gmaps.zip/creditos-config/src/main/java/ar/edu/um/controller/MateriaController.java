package ar.edu.um.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ar.edu.um.domain.Anio;
import ar.edu.um.domain.Carrera;
import ar.edu.um.domain.GMaps;
import ar.edu.um.domain.Materia;
import ar.edu.um.form.AnioEditor;
import ar.edu.um.form.CarreraEditor;
import ar.edu.um.services.AnioService;
import ar.edu.um.services.CarreraService;
import ar.edu.um.services.MateriaService;

@Controller
@RequestMapping("/materias")
public class MateriaController {
	
	@Autowired
	private CarreraService carreraService;
	
	@Autowired
	private MateriaService materiaService;
	
	@Autowired
	private AnioService anioService;
	
	private static final Logger logger = LoggerFactory
			.getLogger(MateriaController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		model.addAttribute("materias", materiaService.findAll());
		String original = request.getParameter("q");
		
		logger.info("Info del UTF" + request.getCharacterEncoding());
		
		logger.info("Parametro	 "+ original);
		return "materias/tabla";
	}
	
	
	@RequestMapping(value = "/nuevo", method = RequestMethod.GET)
	public String nuevo(Model model){
		model.addAttribute("materia", new Materia());
		model.addAttribute("carreras", carreraService.findAll());
		model.addAttribute("anios", anioService.findAll());
		return "materias/nuevo";
	}
	
	@RequestMapping(value="/nuevo", method= RequestMethod.POST)
	public String form(@Valid Materia materia, BindingResult result,
			 Model model) throws UnsupportedEncodingException{
		if (!result.hasErrors()) {
			
			
			materiaService.create(materia);
			return "redirect:/materias/";
		} else {
			for (ObjectError error : result.getAllErrors()) {
				logger.info("Validation error: " + error.getObjectName()+", "+ error.getDefaultMessage());
			}
		}
		model.addAttribute("anios", anioService.findAll());
		model.addAttribute("carreras", carreraService.findAll());
		return "materias/nuevo";
	}
	
	@RequestMapping(value = "/{id}/editar", method = RequestMethod.GET)
	public String editar(@PathVariable("id") Integer id, Model model) {
		Materia materia = materiaService.findById(id);
		if (materia != null) {
			model.addAttribute("materia", materia);
			model.addAttribute("anios", anioService.findAll());
			model.addAttribute("carreras", carreraService.findAll());
		}

		return "materias/editar";
	}
	
	@RequestMapping(value = "/{id}/editar", method = RequestMethod.POST)
	public String formEditar(@PathVariable("id") Integer id,
			@Valid Materia materia, BindingResult result,HttpServletRequest request, Model model
			) throws UnsupportedEncodingException {
		
		if (!result.hasErrors()) {
			
			logger.info("Nombre decoded "+ request.getCharacterEncoding() +", " + request.getContentType() +", " +request.getParameter("test"));
			
			materiaService.update(materia);
			
			return "redirect:/materias/";
		  } else {
			for (ObjectError error : result.getAllErrors()) {
				logger.info("Validation error: " + error.getDefaultMessage());
			}
			model.addAttribute("anios", anioService.findAll());
			model.addAttribute("carreras", carreraService.findAll());
		}
		
		return "redirect:/materias/";
	}
	
	@RequestMapping(value = "/{id}/borrar", method = RequestMethod.GET)
	public String borrar(@PathVariable("id") Integer id, Model model, final RedirectAttributes redirectAttributes) {
		Materia materia = materiaService.findById(id);
		if(materia != null){
			materiaService.remove(materia);
			redirectAttributes.addFlashAttribute("message", "Materia borrada.");
			redirectAttributes.addFlashAttribute("cssmessage", "alert-warning");
		}
		
		return "redirect:/materias/";
	}
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Anio.class, new AnioEditor(this.anioService));
		binder.registerCustomEditor(Carrera.class, new CarreraEditor(this.carreraService));
	}
}
