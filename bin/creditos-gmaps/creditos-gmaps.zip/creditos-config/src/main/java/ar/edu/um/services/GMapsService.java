package ar.edu.um.services;

import java.util.List;

import ar.edu.um.domain.GMaps;

public interface GMapsService {
	void create(final GMaps entity);
	void remove(final GMaps entity);
	void update(final GMaps entity);
	GMaps findById(final Integer id);

	List<GMaps> findAll();
}
