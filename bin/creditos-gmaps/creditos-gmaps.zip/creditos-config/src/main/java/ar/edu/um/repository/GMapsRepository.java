package ar.edu.um.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.um.domain.GMaps;

public interface GMapsRepository extends JpaRepository<GMaps, Integer> {

}
