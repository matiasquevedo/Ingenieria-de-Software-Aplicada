package ar.edu.um.domain;

public class Rol {
	
	private Integer id;
	private String nombre;
	private String tipo;

}
